# Code of Conduct

The Code of Conduct is available in the PyScript Governance repo.
See https://github.com/pyscript/governance/blob/main/CODE-OF-CONDUCT.md
