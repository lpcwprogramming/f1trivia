module.exports = {
    arrowParens: 'avoid',
    bracketSameLine: true,
    singleQuote: true,
    printWidth: 120,
    semi: true,
    tabWidth: 4,
    trailingComma: 'all',
};
